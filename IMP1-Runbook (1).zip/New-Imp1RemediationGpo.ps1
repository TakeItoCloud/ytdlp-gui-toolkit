#Requires -Modules GroupPolicy, ActiveDirectory
<#
.SYNOPSIS
    Creates the GPO + empty security group for an IMP1 item, links it at the domain root and
    applies MS16-072-safe security filtering - with full logging. The group starts EMPTY, so the
    GPO applies to nobody until you add machines (this is what makes the canary rollout safe).
.DESCRIPTION
    Run from a management station / DC with RSAT. Table-driven per item. WinVerifyTrust writes the
    registry values into the GPO (Set-GPRegistryValue on the normal, non-policy Wintrust key, so it
    tattoos/persists). The two G11 items create the GPO/link/filter and log a manual note to attach
    the startup script (or remediate with Invoke-Command). Writes a structured .log and evidence .csv.
.PARAMETER Item
    WinVerifyTrust | UnquotedServicePaths | InsecureServicePerms
.PARAMETER GroupName  Security group granted Apply. Default grp-IMP1-<Item>. Created if -CreateGroup.
.PARAMETER LinkTarget DN to link to. Default domain root (reaches servers AND DCs).
.PARAMETER GroupOU    OU DN for the new group (default CN=Users).
.PARAMETER CreateGroup Create the group if missing.
.PARAMETER LogDirectory Where .log/.csv are written. Default .\IMP1-Logs
.EXAMPLE
    .\New-Imp1RemediationGpo.ps1 -Item WinVerifyTrust -CreateGroup -WhatIf
.OUTPUTS
    PSCustomObject
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
[OutputType([pscustomobject])]
param(
    [Parameter(Mandatory)][ValidateSet('WinVerifyTrust','UnquotedServicePaths','InsecureServicePerms')][string]$Item,
    [string]$GroupName,[string]$LinkTarget,[string]$GroupOU,[switch]$CreateGroup,[string]$LogDirectory
)

begin {
    $InformationPreference = 'Continue'
    Import-Module GroupPolicy, ActiveDirectory -ErrorAction Stop
    $runStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    if (-not $LogDirectory) { $LogDirectory = Join-Path (Get-Location).Path 'IMP1-Logs' }
    New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    $LogFile = Join-Path $LogDirectory "New-Imp1RemediationGpo-$Item-$runStamp.log"
    $CsvFile = Join-Path $LogDirectory "New-Imp1RemediationGpo-$Item-$runStamp.csv"
    function Write-Log {
        param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR','ACTION','RESULT')][string]$Level='INFO')
        $line = '{0} [{1,-6}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Message
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
        if ($Level -eq 'WARN') { Write-Warning $Message } elseif ($Level -eq 'ERROR') { Write-Error $Message -ErrorAction Continue } else { Write-Verbose $line }
    }
    $domainDN = (Get-ADDomain).DistinguishedName
    if (-not $LinkTarget) { $LinkTarget = $domainDN }
    if (-not $GroupOU)    { $GroupOU    = "CN=Users,$domainDN" }
    $catalog = @{
        WinVerifyTrust = @{ Gpo='GPO-IMP1-WinVerifyTrust-CVE-2013-3900'; Group='grp-IMP1-WinVerifyTrust'; Type='Registry'
            Reg=@(@{Key='HKLM\SOFTWARE\Microsoft\Cryptography\Wintrust\Config';Name='EnableCertPaddingCheck';Type='String';Value='1'}
                  @{Key='HKLM\SOFTWARE\Wow6432Node\Microsoft\Cryptography\Wintrust\Config';Name='EnableCertPaddingCheck';Type='String';Value='1'}) }
        UnquotedServicePaths = @{ Gpo='GPO-IMP1-UnquotedServicePaths'; Group='grp-IMP1-UnquotedServicePaths'; Type='StartupScript'
            ScriptHint='Repair-UnquotedServicePath.ps1 (-Mode Apply)' }
        InsecureServicePerms = @{ Gpo='GPO-IMP1-InsecureServicePerms'; Group='grp-IMP1-InsecureServicePerms'; Type='StartupScript'
            ScriptHint='Repair-InsecureServicePermission.ps1 (-Mode Apply) - or Invoke-Command for a few hosts' }
    }
    $def = $catalog[$Item]
    if (-not $GroupName) { $GroupName = $def.Group }
    Write-Log "=== New-Imp1RemediationGpo started by $env:USERDOMAIN\$env:USERNAME on $env:COMPUTERNAME ==="
    Write-Log "Item=$Item GPO=$($def.Gpo) Group=$GroupName Link=$LinkTarget WhatIf=$WhatIfPreference"
}

process {
    # 1. Group (empty)
    $grp = Get-ADGroup -Filter "Name -eq '$GroupName'" -ErrorAction SilentlyContinue
    if (-not $grp) {
        if ($CreateGroup) {
            if ($PSCmdlet.ShouldProcess($GroupName, "Create global security group in $GroupOU")) {
                $grp = New-ADGroup -Name $GroupName -GroupScope Global -GroupCategory Security -Path $GroupOU -PassThru -ErrorAction Stop
                Write-Log "CREATED group $($grp.DistinguishedName)" 'ACTION'
            }
        } else { throw "Group '$GroupName' not found. Re-run with -CreateGroup." }
    } else { Write-Log "Group exists: $($grp.DistinguishedName)" }

    # 2. GPO
    $gpo = Get-GPO -Name $def.Gpo -ErrorAction SilentlyContinue
    if (-not $gpo) {
        if ($PSCmdlet.ShouldProcess($def.Gpo,'Create GPO')) {
            $gpo = New-GPO -Name $def.Gpo -Comment "IMP1 remediation ($Item). Filtered to $GroupName." -ErrorAction Stop
            Write-Log "CREATED GPO $($def.Gpo) [$($gpo.Id)]" 'ACTION'
        }
    } else { Write-Log "GPO exists: $($def.Gpo) [$($gpo.Id)]" }

    # 3. Configure
    if ($def.Type -eq 'Registry') {
        foreach ($r in $def.Reg) {
            if ($PSCmdlet.ShouldProcess("$($def.Gpo): $($r.Key)\$($r.Name)", "Set $($r.Type)=$($r.Value)")) {
                Set-GPRegistryValue -Name $def.Gpo -Key $r.Key -ValueName $r.Name -Type $r.Type -Value $r.Value -ErrorAction Stop | Out-Null
                Write-Log "SET $($r.Key)\$($r.Name) = $($r.Value) ($($r.Type))" 'ACTION'
            }
        }
    } else { Write-Log "MANUAL: attach startup script in GPME -> $($def.ScriptHint) (or use Invoke-Command)" 'WARN' }

    # 4. Link at domain root
    $linked = Get-GPInheritance -Target $LinkTarget -ErrorAction SilentlyContinue
    if ($linked.GpoLinks.DisplayName -notcontains $def.Gpo) {
        if ($PSCmdlet.ShouldProcess("$($def.Gpo) -> $LinkTarget",'Link GPO')) {
            New-GPLink -Name $def.Gpo -Target $LinkTarget -LinkEnabled Yes -ErrorAction Stop | Out-Null
            Write-Log "LINKED $($def.Gpo) -> $LinkTarget" 'ACTION'
        }
    } else { Write-Log "Already linked: $($def.Gpo) -> $LinkTarget" }

    # 5. Security filtering (MS16-072-safe)
    if ($grp -and $PSCmdlet.ShouldProcess($def.Gpo, "Filter Apply=$GroupName; AuthUsers=Read")) {
        Set-GPPermission -Name $def.Gpo -TargetName $GroupName -TargetType Group -PermissionLevel GpoApply -Replace -ErrorAction Stop | Out-Null
        Set-GPPermission -Name $def.Gpo -TargetName 'Authenticated Users' -TargetType Group -PermissionLevel GpoRead -Replace -ErrorAction Stop | Out-Null
        Write-Log "FILTER set: Apply=$GroupName, Authenticated Users=Read" 'ACTION'
    }

    $o = [pscustomobject]@{ Item=$Item; Gpo=$def.Gpo; Type=$def.Type; Group=$GroupName; LinkedTo=$LinkTarget
        NextStep='Group is EMPTY. Add 3 canaries (Add-Imp1MachinesToGroup.ps1 -Path <CANARY.txt>), validate, then the rest.' }
    [void]$o; $o | Export-Csv -LiteralPath $CsvFile -NoTypeInformation -Encoding UTF8
    Write-Log "DONE. Next: add canaries to $GroupName, validate, then the rest." 'RESULT'
    Write-Information ("GPO {0} ready, filtered to EMPTY group {1} (linked {2})." -f $def.Gpo,$GroupName,$LinkTarget)
    Write-Information (" log: {0}" -f $LogFile)
    $o
}
