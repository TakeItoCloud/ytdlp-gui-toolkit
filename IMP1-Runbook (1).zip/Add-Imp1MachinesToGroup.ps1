#Requires -Modules ActiveDirectory
<#
.SYNOPSIS
    Adds the computers in a .txt list to a security group (the way an IMP1 GPO is scoped) with
    full logging. Idempotent: run the CANARY list for wave 1, the full list for wave 2 (members
    already present are skipped).
.DESCRIPTION
    Resolves each host to its AD computer object and adds it to the target group. Nothing is
    moved, so it is safe for Domain Controllers and multi-group machines. Coverage-aware: hosts
    not found in AD are reported. Defaults to -WhatIf via ShouldProcess. Writes a structured .log
    and an evidence .csv per run to -LogDirectory.
.PARAMETER Path
    Path to the .txt host list (canary file for wave 1, full file for wave 2).
.PARAMETER GroupName
    Target security group (e.g. grp-IMP1-WinVerifyTrust).
.PARAMETER LogDirectory
    Where the .log and .csv are written. Default .\IMP1-Logs
.EXAMPLE
    .\Add-Imp1MachinesToGroup.ps1 -Path .\IMP1-166555-WinVerifyTrust-CANARY.txt -GroupName grp-IMP1-WinVerifyTrust -WhatIf
.EXAMPLE
    .\Add-Imp1MachinesToGroup.ps1 -Path .\IMP1-166555-WinVerifyTrust-hosts.txt  -GroupName grp-IMP1-WinVerifyTrust -Verbose
.OUTPUTS
    PSCustomObject (Host, SamAccount, Status)
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
[OutputType([pscustomobject])]
param(
    [Parameter(Mandatory)][ValidateScript({ Test-Path $_ })][string]$Path,
    [Parameter(Mandatory)][string]$GroupName,
    [string]$LogDirectory
)

begin {
    $InformationPreference = 'Continue'
    Import-Module ActiveDirectory -ErrorAction Stop
    $runStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    if (-not $LogDirectory) { $LogDirectory = Join-Path (Get-Location).Path 'IMP1-Logs' }
    New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    $base    = "Add-Imp1MachinesToGroup-$GroupName-$runStamp"
    $LogFile = Join-Path $LogDirectory "$base.log"
    $CsvFile = Join-Path $LogDirectory "$base.csv"
    function Write-Log {
        param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR','ACTION','RESULT')][string]$Level='INFO')
        $line = '{0} [{1,-6}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Message
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
        if ($Level -eq 'WARN') { Write-Warning $Message } elseif ($Level -eq 'ERROR') { Write-Error $Message -ErrorAction Continue } else { Write-Verbose $line }
    }
    $results = New-Object System.Collections.Generic.List[object]
    if (-not (Get-ADGroup -Filter "Name -eq '$GroupName'" -ErrorAction SilentlyContinue)) {
        throw "Group '$GroupName' not found. Create it first (New-Imp1RemediationGpo.ps1 -CreateGroup)."
    }
    $hosts = Get-Content -Path $Path | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') }
    Write-Log "=== Add-to-group started by $env:USERDOMAIN\$env:USERNAME on $env:COMPUTERNAME ==="
    Write-Log "Group=$GroupName  List=$Path  Hosts=$($hosts.Count)  WhatIf=$($WhatIfPreference)"
}

process {
    foreach ($h in $hosts) {
        $short = ($h -split '\.')[0]
        try {
            $c = Get-ADComputer -Filter "Name -eq '$short'" -ErrorAction Stop
            if (-not $c) {
                $o = [pscustomobject]@{ Host=$h; SamAccount=$short; Status='NOT FOUND in AD - not assessed' }
                Write-Log "RESOLVE $h -> NOT FOUND in AD" 'WARN'
            }
            elseif ($PSCmdlet.ShouldProcess($c.DistinguishedName, "Add to $GroupName")) {
                Add-ADGroupMember -Identity $GroupName -Members $c -ErrorAction Stop
                $o = [pscustomobject]@{ Host=$h; SamAccount="$short$"; Status='Added' }
                Write-Log "ADDED $($c.DistinguishedName) -> $GroupName" 'ACTION'
            }
            else {
                $o = [pscustomobject]@{ Host=$h; SamAccount="$short$"; Status='WhatIf - would add' }
                Write-Log "WHATIF would add $($c.DistinguishedName) -> $GroupName" 'INFO'
            }
        }
        catch {
            $status = if ($_.Exception.Message -match 'already a member') { 'Already a member' } else { "Error: $($_.Exception.Message)" }
            $o = [pscustomobject]@{ Host=$h; SamAccount=$short; Status=$status }
            Write-Log "RESULT $h -> $status" ($(if($status -like 'Error*'){'ERROR'}else{'INFO'}))
        }
        $results.Add($o); $o
    }
}

end {
    if ($results.Count) { $results | Export-Csv -LiteralPath $CsvFile -NoTypeInformation -Encoding UTF8 }
    $added = @($results | Where-Object Status -eq 'Added').Count
    $already = @($results | Where-Object Status -eq 'Already a member').Count
    $missing = @($results | Where-Object Status -like 'NOT FOUND*').Count
    $errors  = @($results | Where-Object Status -like 'Error*').Count
    Write-Log "SUMMARY added=$added already=$already notfound=$missing errors=$errors of $($results.Count)" 'RESULT'
    Write-Log "Evidence CSV: $CsvFile"
    Write-Information ("Add-to-group {0}: added {1}, already {2}, not-found {3}, errors {4}" -f $GroupName,$added,$already,$missing,$errors)
    Write-Information (" log: {0}" -f $LogFile)
    Write-Information (" csv: {0}" -f $CsvFile)
}
