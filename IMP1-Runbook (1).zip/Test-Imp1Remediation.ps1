#Requires -Version 5.1
<#
.SYNOPSIS
    CONFIRMATION TEST. Verifies, per machine, that an IMP1 item is actually solved on the host
    (not merely that the GPO was linked) and emits an explicit SOLVED / NOT-SOLVED verdict.
    Full logging: writes a structured .log and an evidence .csv per run.
.DESCRIPTION
    Runs the right read-only check for the item on every host in the list via Invoke-Command and
    returns Compliant True/False + detail. Coverage-aware: unreachable hosts are NotAssessed,
    never counted as solved. At the end it logs and prints a verdict (solved X/Y, lists the
    hosts not solved and the unreachable ones). Run it on the CANARY list after wave 1 and on
    the full list after wave 2 (and later, to detect drift). Changes nothing.
      WinVerifyTrust        -> EnableCertPaddingCheck = "1" on both Wintrust keys
      UnquotedServicePaths  -> zero services with an unquoted, space-containing ImagePath
      InsecureServicePerms  -> zero service DACLs granting dangerous rights to unsafe principals
.PARAMETER Item
    WinVerifyTrust | UnquotedServicePaths | InsecureServicePerms
.PARAMETER Path
    Path to the machine .txt list (canary or full).
.PARAMETER Credential
    Optional credential for the remote sessions.
.PARAMETER LogDirectory
    Where the .log and .csv evidence are written. Default .\IMP1-Logs
.EXAMPLE
    .\Test-Imp1Remediation.ps1 -Item WinVerifyTrust -Path .\IMP1-166555-WinVerifyTrust-CANARY.txt
.OUTPUTS
    PSCustomObject (Host, Item, Reachable, Compliant, Detail)
#>
[CmdletBinding()]
[OutputType([pscustomobject])]
param(
    [Parameter(Mandatory)][ValidateSet('WinVerifyTrust','UnquotedServicePaths','InsecureServicePerms')][string]$Item,
    [Parameter(Mandatory)][ValidateScript({ Test-Path $_ })][string]$Path,
    [pscredential]$Credential,
    [string]$LogDirectory
)

begin {
    $InformationPreference = 'Continue'
    $runStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    if (-not $LogDirectory) { $LogDirectory = Join-Path (Get-Location).Path 'IMP1-Logs' }
    New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    $base    = "Test-Imp1Remediation-$Item-$runStamp"
    $LogFile = Join-Path $LogDirectory "$base.log"
    $CsvFile = Join-Path $LogDirectory "$base.csv"
    function Write-Log {
        param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR','RESULT')][string]$Level='INFO')
        $line = '{0} [{1,-6}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Message
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
        if ($Level -eq 'WARN') { Write-Warning $Message } elseif ($Level -eq 'ERROR') { Write-Error $Message -ErrorAction Continue } else { Write-Verbose $line }
    }
    $results = New-Object System.Collections.Generic.List[object]
    $hosts = Get-Content -Path $Path | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') }
    Write-Log "=== CONFIRMATION TEST started by $env:USERDOMAIN\$env:USERNAME on $env:COMPUTERNAME ==="
    Write-Log "Item=$Item  List=$Path  Hosts=$($hosts.Count)"

    $checks = @{
        WinVerifyTrust = {
            $k1 = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography\Wintrust\Config' -Name EnableCertPaddingCheck -EA SilentlyContinue).EnableCertPaddingCheck
            $k2 = (Get-ItemProperty 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Cryptography\Wintrust\Config' -Name EnableCertPaddingCheck -EA SilentlyContinue).EnableCertPaddingCheck
            [pscustomobject]@{ Compliant = ($k1 -eq '1' -and $k2 -eq '1'); Detail = "native=$([string]$k1); wow6432=$([string]$k2)" }
        }
        UnquotedServicePaths = {
            $bad=@(); foreach ($s in Get-CimInstance Win32_Service -EA SilentlyContinue) {
                $p=$s.PathName; if ([string]::IsNullOrWhiteSpace($p)){continue}; if ($p.TrimStart().StartsWith('"')){continue}
                if ($p -notmatch '\.exe'){continue}; $exe=($p -split '(?<=\.exe)',2)[0]; if ($exe -match '\s'){$bad+=$s.Name} }
            [pscustomobject]@{ Compliant = ($bad.Count -eq 0); Detail = if ($bad){"still unquoted: $($bad -join ',')"}else{'none'} }
        }
        InsecureServicePerms = {
            $unsafe=@('WD','AU','BU','IU','AN','DU'); $danger=@('DC','WD','WO','SD','GA','GW'); $bad=@()
            foreach ($s in Get-CimInstance Win32_Service -EA SilentlyContinue) {
                $sddl=(& sc.exe sdshow $s.Name 2>$null | Where-Object {$_ -match '\S'}) -join ''
                if ($sddl -notmatch 'D:'){continue}; $body=($sddl.Substring($sddl.IndexOf('D:')+2) -split 'S:')[0]
                foreach ($m in [regex]::Matches($body,'\(([^)]*)\)')) { $f=$m.Groups[1].Value -split ';'
                    if ($f[0] -match 'A' -and ($unsafe -contains $f[5])) { foreach ($r in $danger){ if ($f[2] -like "*$r*"){ $bad+="$($s.Name):$($f[5])"; break } } } } }
            [pscustomobject]@{ Compliant = ($bad.Count -eq 0); Detail = if ($bad){($bad|Select-Object -Unique) -join ','}else{'none'} }
        }
    }
    $check = $checks[$Item]
}

process {
    foreach ($h in $hosts) {
        $p = @{ ComputerName=$h; ScriptBlock=$check; ErrorAction='Stop' }
        if ($Credential) { $p.Credential = $Credential }
        try {
            $r = Invoke-Command @p
            $o = [pscustomobject]@{ Host=$h; Item=$Item; Reachable=$true; Compliant=$r.Compliant; Detail=$r.Detail }
            Write-Log ("CHECK {0} Compliant={1} ({2})" -f $h,$r.Compliant,$r.Detail) 'INFO'
        }
        catch {
            $o = [pscustomobject]@{ Host=$h; Item=$Item; Reachable=$false; Compliant='NotAssessed'; Detail="Unreachable: $($_.Exception.Message)" }
            Write-Log ("CHECK {0} UNREACHABLE: {1}" -f $h,$_.Exception.Message) 'WARN'
        }
        $results.Add($o); $o
    }
}

end {
    if ($results.Count) { $results | Export-Csv -LiteralPath $CsvFile -NoTypeInformation -Encoding UTF8 }
    $solved   = @($results | Where-Object Compliant -eq $true).Count
    $notSolved= @($results | Where-Object { $_.Compliant -eq $false })
    $unreach  = @($results | Where-Object { $_.Compliant -eq 'NotAssessed' })
    $total    = $results.Count
    $verdict  = if ($notSolved.Count -eq 0 -and $unreach.Count -eq 0 -and $total -gt 0) { 'SOLVED (all hosts)' }
                elseif ($notSolved.Count -eq 0 -and $unreach.Count -gt 0) { 'SOLVED on reachable hosts; some UNREACHABLE' }
                else { 'NOT SOLVED' }
    Write-Log "VERDICT: $verdict  | solved $solved/$total" 'RESULT'
    if ($notSolved){ Write-Log ("NOT solved: " + ($notSolved.Host -join ', ')) 'RESULT' }
    if ($unreach)  { Write-Log ("Unreachable: " + ($unreach.Host  -join ', ')) 'RESULT' }
    Write-Log "Evidence CSV: $CsvFile"
    Write-Information ""
    Write-Information "=============================================================="
    Write-Information (" {0}  [{1}]" -f $Item,$verdict)
    Write-Information (" solved {0}/{1}   not-solved {2}   unreachable {3}" -f $solved,$total,$notSolved.Count,$unreach.Count)
    if ($notSolved){ Write-Information (" NOT solved : " + ($notSolved.Host -join ', ')) }
    if ($unreach)  { Write-Information (" unreachable: " + ($unreach.Host  -join ', ')) }
    Write-Information (" log: {0}" -f $LogFile)
    Write-Information (" csv: {0}" -f $CsvFile)
    Write-Information "=============================================================="
}
