#Requires -Version 5.1
<#
.SYNOPSIS
    Detects (and optionally repairs) services whose DACL grants dangerous rights to non-privileged
    principals - Insecure Windows Service Permissions (Nessus plugin 65057). Full logging: .log +
    evidence .csv per run (incl. the OriginalSDDL for rollback). Report mode is read-only.
.DESCRIPTION
    Reads each service SDDL (sc.exe sdshow), flags Allow ACEs where an unsafe principal (Everyone,
    Authenticated Users, Users, Interactive, Anonymous, Domain Users) holds a dangerous right
    (DC/WD/WO/SD/GA/GW). Apply removes ONLY the flagged ACEs (no blanket reset) via sc.exe sdset,
    per service, through ShouldProcess. No service restart needed. Logs under -LogDirectory on the
    host it runs on (default C:\ProgramData\IMP1-Logs).
.PARAMETER Mode  Report (default) or Apply.
.PARAMETER UnsafePrincipal  SDDL SIDs treated as non-privileged. Default WD,AU,BU,IU,AN,DU.
.PARAMETER DangerousRight   SDDL rights treated as escalation-enabling. Default DC,WD,WO,SD,GA,GW.
.PARAMETER LogDirectory  Default C:\ProgramData\IMP1-Logs
.EXAMPLE  .\Repair-InsecureServicePermission.ps1
.EXAMPLE  .\Repair-InsecureServicePermission.ps1 -Mode Apply -WhatIf
.OUTPUTS  PSCustomObject (Service, UnsafePrincipal, GrantedRights, OriginalSDDL, NewSDDL, Applied, Mode)
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
[OutputType([pscustomobject])]
param(
    [ValidateSet('Report','Apply')][string]$Mode = 'Report',
    [string[]]$UnsafePrincipal = @('WD','AU','BU','IU','AN','DU'),
    [string[]]$DangerousRight   = @('DC','WD','WO','SD','GA','GW'),
    [string]$LogDirectory = 'C:\ProgramData\IMP1-Logs'
)

begin {
    $InformationPreference = 'Continue'
    $runStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
    $LogFile = Join-Path $LogDirectory "Repair-InsecureServicePermission-$env:COMPUTERNAME-$runStamp.log"
    $CsvFile = Join-Path $LogDirectory "Repair-InsecureServicePermission-$env:COMPUTERNAME-$runStamp.csv"
    function Write-Log {
        param([Parameter(Mandatory)][string]$Message,[ValidateSet('INFO','WARN','ERROR','ACTION','RESULT')][string]$Level='INFO')
        $line = '{0} [{1,-6}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Level,$Message
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
        if ($Level -eq 'WARN') { Write-Warning $Message } elseif ($Level -eq 'ERROR') { Write-Error $Message -ErrorAction Continue } else { Write-Verbose $line }
    }
    function Get-ServiceSddl { param([string]$Name)
        $raw = (& sc.exe sdshow $Name 2>$null | Where-Object { $_ -match '\S' }) -join ''
        if ($raw -match '^[DOGS]:') { $raw.Trim() } }
    function Split-Dacl { param([string]$Sddl)
        if ($Sddl -notmatch 'D:') { return $null }
        $d=$Sddl.IndexOf('D:'); $rest=$Sddl.Substring($d+2); $s=$rest.IndexOf('S:')
        if ($s -ge 0) { @{Prefix=$Sddl.Substring(0,$d)+'D:';Body=$rest.Substring(0,$s);Suffix=$rest.Substring($s)} }
        else { @{Prefix=$Sddl.Substring(0,$d)+'D:';Body=$rest;Suffix=''} } }
    $results = New-Object System.Collections.Generic.List[object]
    Write-Log "=== Repair-InsecureServicePermission Mode=$Mode on $env:COMPUTERNAME by $env:USERNAME (WhatIf=$WhatIfPreference) ==="
}

process {
    foreach ($svc in Get-CimInstance -ClassName Win32_Service -ErrorAction SilentlyContinue) {
        $sddl = Get-ServiceSddl -Name $svc.Name
        if (-not $sddl) { continue }
        $parts = Split-Dacl -Sddl $sddl
        if (-not $parts) { continue }
        $aces = [regex]::Matches($parts.Body,'\(([^)]*)\)') | ForEach-Object { $_.Groups[1].Value }
        $keep = New-Object System.Collections.Generic.List[string]; $flagged=@()
        foreach ($ace in $aces) {
            $f = $ace -split ';'; $type=$f[0]; $rights=$f[2]; $sid=$f[5]
            $danger=$false; foreach ($r in $DangerousRight){ if ($rights -like "*$r*"){ $danger=$true; break } }
            if (($type -match 'A') -and ($UnsafePrincipal -contains $sid) -and $danger) { $flagged += [pscustomobject]@{Sid=$sid;Rights=$rights} }
            else { $keep.Add("($ace)") }
        }
        if ($flagged.Count -eq 0) { continue }
        $newSddl = $parts.Prefix + ($keep -join '') + $parts.Suffix
        Write-Log "FLAG $($svc.Name) unsafe=[$($flagged.Sid -join ',')] rights=[$($flagged.Rights -join '|')]" 'INFO'
        Write-Log "ORIG $($svc.Name) SDDL=$sddl" 'INFO'
        $applied=$false
        if ($Mode -eq 'Apply') {
            if ($PSCmdlet.ShouldProcess($svc.Name,"Remove insecure ACE(s) for $($flagged.Sid -join ',')")) {
                try { & sc.exe sdset $svc.Name $newSddl | Out-Null
                    if ($LASTEXITCODE -ne 0){ throw "sc.exe sdset exit code $LASTEXITCODE" }
                    $applied=$true; Write-Log "FIXED $($svc.Name) NewSDDL=$newSddl" 'ACTION'
                } catch { Write-Log "FAILED $($svc.Name): $($_.Exception.Message)" 'ERROR' }
            }
        }
        $o = [pscustomobject]@{ Service=$svc.Name; UnsafePrincipal=($flagged.Sid -join ', '); GrantedRights=($flagged.Rights -join ' | '); OriginalSDDL=$sddl; NewSDDL=$newSddl; Applied=$applied; Mode=$Mode }
        $results.Add($o); $o
    }
}

end {
    if ($results.Count) { $results | Export-Csv -LiteralPath $CsvFile -NoTypeInformation -Encoding UTF8 }
    $fixed = @($results | Where-Object Applied -eq $true).Count
    Write-Log "SUMMARY flagged=$($results.Count) fixed=$fixed Mode=$Mode" 'RESULT'
    Write-Log "Evidence CSV (incl. OriginalSDDL for rollback): $CsvFile"
    Write-Information ("[{0}] insecure-svc-perms: flagged {1}, fixed {2} (Mode={3})" -f $env:COMPUTERNAME,$results.Count,$fixed,$Mode)
    Write-Information (" log: {0}" -f $LogFile)
}
